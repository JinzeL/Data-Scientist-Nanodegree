from setuptools import setup

setup(name='ljz_distributions',
      version='0.21',
      description='Gaussian and Binomial distributions',
      packages=['ljz_distributions'],
      author = 'Jinze Li',
      author_email = 'lijinze0704@gmail.com',
      zip_safe=False)
